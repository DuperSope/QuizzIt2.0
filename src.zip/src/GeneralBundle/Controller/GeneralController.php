<?php

namespace GeneralBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use QuizzBundle\Entity\Quizz;
use QuizzBundle\Entity\Question;
use QuizzBundle\Form\QuizzType;

class GeneralController extends Controller
{
    public function indexAction()
    {
        return $this->render('GeneralBundle::index.html.twig');
    }
    
    public function myquizzAction()
    {
        // Récupération de l'ORM et de la request et de la session + données user
        $em = $this->getDoctrine()->getManager();
        $request = $this->container->get('request_stack')->getCurrentRequest();
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        
        // Création du form Quizz et des questions
        $quizz = new Quizz;
        $formquizz = $this->createForm(QuizzType::class, $quizz);
        
        // Récupération de Mes Quizz
        $r_quizz = $em->getRepository("QuizzBundle:Quizz");
        $quizz_array = $r_quizz->findBy(array('user' => $user->getId()),
                array('id' => 'desc')
                );
        
        // SI un quizz a été créé :
        $formquizz->handleRequest($request);
        if ($formquizz->isSubmitted() && $formquizz->isValid()) {
            $manager = $this->container->get('quizzmanager');
            $manager->addQuizz($formquizz, $request, $quizz, new Question, $em, $user);
            
            return $this->redirectToRoute('myquizz');
        }
        
        return $this->render('GeneralBundle:UserZone:myquizz.html.twig', array(
            'quizzarray' => $quizz_array,
            'form' => $formquizz->createView(),
        ));
    }
    
    
    public function myresultsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $request = $this->container->get('request_stack')->getCurrentRequest();
        $session = $this->get('session');
        $user = $this->container->get('security.token_storage')->getToken()->getUser();
        
                // Récupération de Mes Résultats
        $r_quizzdone = $em->getRepository("QuizzBundle:QuizzDone");
        $quizzdone_array = $r_quizzdone->findBy(array('user' => $user->getId()),
                array('id' => 'desc'),
                1000,
                0
                );
        
        return $this->render('GeneralBundle:UserZone:myresults.html.twig', array(
            'quizzdonearray' => $quizzdone_array,
        ));
    }
}
