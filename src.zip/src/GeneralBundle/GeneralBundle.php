<?php

namespace GeneralBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GeneralBundle extends Bundle
{
}
