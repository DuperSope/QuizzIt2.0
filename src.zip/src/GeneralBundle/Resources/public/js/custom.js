// MYQUIZZ _____________________________________________________________________
    $myquizz_question_i = 0;
    $myquizz_QCM_Q= [''];
    
    function addQuestionField() { // Ajoute un panneau QUESTION
        $myquizz_question_i ++;
        
        $('#questionlinkcontainer li').eq(-2).before(addQuestionLink());
        $('#createquizz_content').append(addQuestionForm());
        
        $('.nav-tabs a[href="#createquizz_q'+ $myquizz_question_i + '"]').tab('show');
    }    
    function addQuestionForm() { // Gère le panneau QUESTION
        $(".suppquestion").remove();
        
        // Ajout des boutons questiontype
        $proto = '<div class="tab-pane fade col-xs-9" id="createquizz_q__name__">  <input type="hidden" name="TYPE___name__" id="TYPE___name__"><h1>Question n°__name__</h1><hr /><span id="suppquestionspace__name__"><button i="__name__" class="btn btn-warning suppquestion" id="suppquestion__name__" onClick="suppQuestionForm(this)">Supprimer la question</button></span>';
        $proto = $proto + '<div class="questiontype___name__"><h3>Type de la question<br /><br />';
        $proto = $proto + '<button type="button" i="__name__" onClick="selectQuestionType(this)" class="btn questiontype_btn TEXT" id="Qtype___name___TEXT">Texte</button> <button type="button" i="__name__" onClick="selectQuestionType(this)" class="btn questiontype_btn QCM" id="Qtype___name___QCM">QCM</button>';
        $proto = $proto + '</h3><div id="questioncontainer__name__"></div></div>'; // Ajout du questioncontainer
        
        $form = $proto.replace(/__name__/g, $myquizz_question_i);
        
        return $form;
    }
    function addQuestionLink() { // Gère le lien QUESTION
        $link = '<li id="qlink___name__" class=""><a href="#createquizz_q__name__" data-toggle="tab">Question __name__</a></li>';
        
        $finallink = $link.replace(/__name__/g, $myquizz_question_i);
        
        return $finallink;
    }
    function suppQuestionForm(element) {
        $i = $(element).attr("i");
        
        $myquizz_question_i --;
        $("#createquizz_q"+$i).remove();
        $("#qlink_"+$i).remove();
        
        $("#suppquestionspace"+$myquizz_question_i).append('<button type="button" i="'+$myquizz_question_i+'" class="btn btn-warning suppquestion" id="suppquestion'+$myquizz_question_i+'" onClick="suppQuestionForm(this)">Supprimer la question</button>');
        $('.nav-tabs a[href="#createquizz_q'+ $myquizz_question_i + '"]').tab('show');

    }
    
    
    function selectQuestionType(element) {
        $question_label = $('#proto_question_label').data('prototype');     // On récupère les prototypes
        $question_widget = $('#proto_question_widget').data('prototype');
        
        $questiontype = $(element).attr('class').substr(20).trim();                // On récupère le type de question et l'id de la question
        $i = $(element).attr('i');

        $('[i="'+$i+'"]').removeClass('btn-primary');                       // Style bouton
        $(element).addClass('btn-primary');
        
        $toadd = '<br />';                                                  // Affichage de la question et du champ
        $toadd = $toadd + $question_label + ' :<br />' + $question_widget;
        $toadd = $toadd.replace(/__name__/g, $i);
        
        $answerfield = setAnswer($questiontype, $i);
        $toadd = $toadd + $answerfield;
        
        
        $('#questioncontainer'+$i).empty();
        $('#questioncontainer'+$i).append($toadd);
    }
    function setAnswer($questiontype, $i) 
    {
        if($questiontype === "TEXT") {                                      // Si la question est de type TEXT
            $answer_label = $('#proto_answer_label').data('prototype');
            $answer_widget = $('#proto_answer_widget').data('prototype');
            $answerfield = "<br /><br />" + $answer_label + " :<br />" + $answer_widget;
            $answerfield = $answerfield.replace(/__name__/g, $i);
            $("#TYPE_"+$i).attr('value', '1');
            return $answerfield;
        }
        
        else if($questiontype === "QCM") {
            $myquizz_QCM_Q[$i] = [0, 0, 1];
            $answerfield = "<br /><h5>Réponses : (cocher la juste)</h5>";
                        
            while($myquizz_QCM_Q[$i][0] < 2) {
                $myquizz_QCM_Q[$i][0] ++;
                $answerfield = $answerfield + '<div id="QCM_Q__name__SPACE___i__" class="row"><br />';
                $answerfield = $answerfield + '<div class="col-xs-1 col-xs-offset-1"><input class="" type="checkbox" name="QCM_Q__name__istrue__i__"></div> <div class="col-xs-8"><input type="text" class="form-control" name="QCM_Q__name__answer__i__"></div>';
                $answerfield = $answerfield + '</div>';
                
                $answerfield = $answerfield.replace(/__i__/g, $myquizz_QCM_Q[$i][0]);
            }
            
            $answerfield = $answerfield + '<br id="beforeme_btn___name__" /><div id="QCM_btns___name__"><button type="button" class="btn btn-default" i="__name__" id="QCM_add___name__" onClick="addChoiceQCM(this)">Ajouter une réponse</button></div>';
            
            $answerfield = $answerfield.replace(/__name__/g, $i);
            $("#TYPE_"+$i).attr('value', '2');
            return $answerfield;
            
        }
        
            
    }
    
    
    function addChoiceQCM(element) {
        $i = $(element).attr('i');
        
        if($myquizz_QCM_Q[$i][0] === 5) {
            alert("Vous ne pouvez pas ajouter une sixième réponse.");
            return false;
        }
        if($myquizz_QCM_Q[$i][0] > 1 && $myquizz_QCM_Q[$i][1] === 0) {
            $toappend = ' <button type="button" class="btn btn-danger" i="__name__" id="QCM_supp___name__" onClick="suppChoiceQCM(this)">Retirer une réponse</button>';
            $toappend = $toappend.replace(/__name__/g, $i);
            $('#QCM_btns_'+$i).append($toappend);
            $myquizz_QCM_Q[$i][1] = 1;
        }
        
        $myquizz_QCM_Q[$i][0] ++;
        $answerfield = '<div id="QCM_Q__name__SPACE___i__" class="row"><br />';
        $answerfield = $answerfield + '<div class="col-xs-1 col-xs-offset-1"><input class="" type="checkbox" name="QCM_Q__name__istrue__i__"></div> <div class="col-xs-8"><input type="text" class="form-control" name="QCM_Q__name__answer__i__"></div>';
        $answerfield = $answerfield + '</div>';

        $answerfield = $answerfield.replace(/__i__/g, $myquizz_QCM_Q[$i][0]);
        $answerfield = $answerfield.replace(/__name__/g, $i);
        
        $('#beforeme_btn_'+$i).before($answerfield);  
    }
    function suppChoiceQCM(element) {
        $i = $(element).attr('i');
        $i_QCM = $myquizz_QCM_Q[$i][0];

        
        $("#QCM_Q"+$i+"SPACE_"+$i_QCM).remove();
        
        $myquizz_QCM_Q[$i][0] --;
        if($myquizz_QCM_Q[$i][0] < 3) {
            $myquizz_QCM_Q[$i][1] = 0;
            $("#QCM_supp_"+$i).remove()
        }
    }
    

//
//$answerfield = '<div id="QCM_Q__name__SPACE">';
//$answerfield = $answerfield + '<input type="checkbox" name="QCM_Q__name__istrue__i__"><input type="text" class="form-control" name="QCM_Q__name__answer__i__">';
//$answerfield = $answerfield + '</div>';