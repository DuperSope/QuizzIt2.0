<?php

namespace QuizzBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use QuizzBundle\Form\QuizzDoneType;
use QuizzBundle\Entity\QuizzDone;
use QuizzBundle\Entity\QuestionDone;

class QuizzController extends Controller
{

    public function previewAction($quizzid) {
        // Récupération de l'em et du repository quizz
        $em = $this->getDoctrine()->getManager();
        $r_quizz = $em->getRepository("QuizzBundle:Quizz");
        $user = $this->container->get('security.token_storage')->getToken()->getUser();

        $owner = 0;
        
        
        $quizz = $r_quizz->findOneById($quizzid);
        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED')) { // Si l'user est connecté
            if($quizz->getUser() == $user->getId()) { // Et que son ID correspond à celui ayant créé le Quizz
                $owner = 1; // La variable owner transmise au document html est égale à 1
            }
        }
        
        return $this->render('QuizzBundle:Quizz:preview.html.twig', array(
            'quizz' => $quizz,
            'owner' => $owner,
        ));
    }
    
    public function doAction($quizzid) {
        // Récupération de l'em et du repository quizz
        $em = $this->getDoctrine()->getManager();
        $r_quizz = $em->getRepository("QuizzBundle:Quizz");
        
        
        $quizz = $r_quizz->findOneById($quizzid);
        
        // Création du form Quizzdone et des questiondone
        $quizzdone = new QuizzDone;
        foreach($quizz->getQuestions() as $question) {
            $questiondone = new QuestionDone;
            $questiondone->setQuestion($question->getQuestion());
            $quizzdone->addQuestiondone($questiondone);
        }
        $formquizzdone = $this->createForm(QuizzDoneType::class, $quizzdone);
        
        
        return $this->render('QuizzBundle:Quizz:do.html.twig', array(
            'quizz' => $quizz,
            'formquizzdone' => $formquizzdone->createView()
        ));
    }
}
