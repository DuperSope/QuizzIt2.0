<?php

namespace QuizzBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;


/**
 * Quizz
 *
 * @ORM\Table(name="quizz")
 * @ORM\Entity(repositoryClass="QuizzBundle\Repository\QuizzRepository")
 */
class Quizz
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=40)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="user_description", type="text", nullable=true)
     */
    private $userDescription;

    /**
     * @var int
     *
     * @ORM\Column(name="level", type="integer")
     */
    private $level;

    /**
     * @var int
     *
     * @ORM\Column(name="topic", type="integer")
     */
    private $topic;

    /**
     * @var bool
     *
     * @ORM\Column(name="back", type="boolean")
     */
    private $back;

    /**
     * @var string
     *
     * @ORM\Column(name="tag", type="text", nullable=true)
     */
    private $tag;

    /**
     * @var int
     *
     * @ORM\Column(name="rate", type="integer", nullable=true)
     */
    private $rate;

    /**
     * @var int
     *
     * @ORM\Column(name="done", type="integer")
     */
    private $done;

    /**
     * @var int
     *
     * @ORM\Column(name="user", type="integer")
     */
    private $user;

    /**
     * @ORM\OneToMany(targetEntity="Question", mappedBy="quizz",  cascade={"persist", "remove"})
     *
     */
    private $questions;
    
    /**
     * @var int
     *
     * @ORM\Column(name="nb_question", type="integer")
     */
    private $nbQuestion;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;
    
    /**
     * @var string
     *
     * @ORM\Column(name="str_level", type="text", nullable=true)
     */
    private $strLevel;
    public function getStrLevel()
    {
        return $this->strLevel;
    }
    public function setStrLevel() {
        $level_array = array(0 => "Autre",
                            1 => "Terminale",
                            2 => "Première",
                            3 => "Seconde",
                            4 => "Troisième",
                            5 => "Quatrième",
                            6 => "Cinquième",
                            7 => "Sixième");
        $this->strLevel = $level_array[$this->level];
    }
    
    /**
     * @var string
     *
     * @ORM\Column(name="str_topic", type="text", nullable=true)
     */
    private $strTopic;
    public function getStrTopic()
    {
        return $this->strTopic;
    }
    public function setStrTopic() {
        $topic_array = array(1 => "Français",
                            2 => "Maths",
                            3 => "Physique Chimie",
                            4 => "SVT",
                            5 => "Histoire Géographie",
                            6 => "Anglais",
                            7 => "Espagnol",
                            8 => "Italien",
                            9 => "Allemand",
                            10 => "Philosophie");  
        $this->strTopic = $topic_array[$this->topic];
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Quizz
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Quizz
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set userDescription
     *
     * @param string $userDescription
     *
     * @return Quizz
     */
    public function setUserDescription($userDescription)
    {
        $this->userDescription = $userDescription;

        return $this;
    }

    /**
     * Get userDescription
     *
     * @return string
     */
    public function getUserDescription()
    {
        return $this->userDescription;
    }

    /**
     * Set level
     *
     * @param integer $level
     *
     * @return Quizz
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return int
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set topic
     *
     * @param integer $topic
     *
     * @return Quizz
     */
    public function setTopic($topic)
    {
        $this->topic = $topic;

        return $this;
    }

    /**
     * Get topic
     *
     * @return int
     */
    public function getTopic()
    {
        return $this->topic;
    }

    /**
     * Set back
     *
     * @param boolean $back
     *
     * @return Quizz
     */
    public function setBack($back)
    {
        $this->back = $back;

        return $this;
    }

    /**
     * Get back
     *
     * @return bool
     */
    public function getBack()
    {
        return $this->back;
    }

    /**
     * Set tag
     *
     * @param string $tag
     *
     * @return Quizz
     */
    public function setTag($tag)
    {
        $this->tag = $tag;

        return $this;
    }

    /**
     * Get tag
     *
     * @return string
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * Set rate
     *
     * @param integer $rate
     *
     * @return Quizz
     */
    public function setRate($rate)
    {
        $this->rate = $rate;

        return $this;
    }

    /**
     * Get rate
     *
     * @return int
     */
    public function getRate()
    {
        return $this->rate;
    }

    /**
     * Set done
     *
     * @param integer $done
     *
     * @return Quizz
     */
    public function setDone($done)
    {
        $this->done = $done;

        return $this;
    }

    /**
     * Get done
     *
     * @return int
     */
    public function getDone()
    {
        return $this->done;
    }

    /**
     * Set user
     *
     * @param integer $user
     *
     * @return Quizz
     */
    public function setUser($user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return int
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set question
     *
     * @param integer $questions
     *
     * @return Quizz
     */
    public function setQuestions($questions)
    {
        $this->questions = $questions;

        return $this;
    }

    /**
     * Get questions
     *
     * @return int
     */
    public function getQuestions()
    {
        return $this->questions;
    }
    
    /**
     * Set nbQuestion
     *
     * @param integer $nbquestion
     *
     * @return Quizz
     */
    public function setNbQuestion($nbquestion)
    {
        $this->nbQuestion = $nbquestion;

        return $this;
    }

    /**
     * Get nbQuestion
     *
     * @return int
     */
    public function getNbQuestion()
    {
        return $this->nbQuestion;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return Quizz
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }
    
    
    
    
    public function __toString() {
        return $this->name;
    }
}

