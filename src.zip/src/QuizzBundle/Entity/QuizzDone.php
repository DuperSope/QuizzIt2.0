<?php

namespace QuizzBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use UserBundle\Entity\User;

/**
 * QuizzDone
 *
 * @ORM\Table(name="quizz_done")
 * @ORM\Entity(repositoryClass="QuizzBundle\Repository\QuizzDoneRepository")
 */
class QuizzDone
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity="Quizz")
     */
    private $quizz;

    /**
     * @ORM\OneToOne(targetEntity="UserBundle\Entity\User")
     */
    private $user;

    /**
     * @ORM\OneToMany(targetEntity="QuestionDone", mappedBy="QuizzDone",  cascade={"persist", "remove"})
     *
     */
    private $questiondone;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set quizz
     *
     * @param integer $quizz
     *
     * @return QuizzDone
     */
    public function setQuizz($quizz)
    {
        $this->quizz = $quizz;

        return $this;
    }

    /**
     * Get quizz
     *
     * @return int
     */
    public function getQuizz()
    {
        return $this->quizz;
    }

    /**
     * Set user
     *
     * @param integer $user
     *
     * @return QuizzDone
     */
    public function setUser($user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return int
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set questiondone
     *
     * @param integer $questiondone
     *
     * @return QuizzDone
     */
    public function setQuestiondone($questiondone)
    {
        $this->questiondone = $questiondone;

        return $this;
    }

    /**
     * Get questiondone
     *
     * @return int
     */
    public function getQuestiondone()
    {
        return $this->questiondone;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return QuizzDone
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->questiondone = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add questiondone
     *
     * @param \QuizzIt\QuizzBundle\Entity\QuestionDone $questiondone
     * @return QuizzDone
     */
    public function addQuestiondone(\QuizzBundle\Entity\QuestionDone $questiondone)
    {
        $this->questiondone[] = $questiondone;

        return $this;
    }

    /**
     * Remove questiondone
     *
     * @param \QuizzIt\QuizzBundle\Entity\QuestionDone $questiondone
     */
    public function removeQuestiondone(\QuizzBundle\Entity\QuestionDone $questiondone)
    {
        $this->questiondone->removeElement($questiondone);
    }
}

