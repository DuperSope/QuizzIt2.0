<?php
// src/QuizzBundle/Manager/QuestionManager.php

namespace QuizzBundle\Manager;

class QuestionManager
{

    public function createQuestion($request, $question, $i) {
        
        $type = $request->request->get("TYPE_".$i);
        
        if($type == '1') {          // Question TEXTE
            $question->setQuestionType(1);
            $question->setAnswer($question->getAnswer());
            $question->setQuestion($question->getQuestion());
        } else if($type == '2') {   // Question QCM
            $question->setQuestionType(2);
            
            $ii = 1;
            $answer = "";
            while(null !== $request->request->get("QCM_Q".$i."answer".$ii)) {
                if(null !== $request->request->get("QCM_Q".$i."istrue".$ii)) {
                    $answer .= "{T}";
                }
                
                $answer .= $request->request->get("QCM_Q".$i."answer".$ii);
                $answer .= "[||]";
                
                $ii++;
            }
            
            $question->setAnswer($answer);
        }
    }
    
    
    public function setId($question, $quizz) {
        $question->setQuizz($quizz);
    }
    
}