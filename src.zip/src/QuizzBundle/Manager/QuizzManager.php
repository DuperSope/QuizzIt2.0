<?php
// src/QuizzBundle/Manager/QuizzManager.php

namespace QuizzBundle\Manager;

class QuizzManager
{
    protected $questionmanager;
    
    private $level_array = array(0 => "Autre",
                            1 => "Terminale",
                            2 => "Première",
                            3 => "Seconde",
                            4 => "Troisième",
                            5 => "Quatrième",
                            6 => "Cinquième",
                            7 => "Sixième");
        
    private $topic_array = array(1 => "Français",
                            2 => "Maths",
                            3 => "Physique Chimie",
                            4 => "SVT",
                            5 => "Histoire Géographie",
                            6 => "Anglais",
                            7 => "Espagnol",
                            8 => "Italien",
                            9 => "Allemand",
                            10 => "Philosophie");
    
    public function __construct($questionmanager) {
        $this->questionmanager = $questionmanager;
    }

    public function addQuizz($formquizz, $request, $quizz, $question, $em, $user) {
        
        $quizz = $formquizz->getData();
        
        $i = 1;
        foreach($quizz->getQuestions() as $question) {
            $this->questionmanager->createQuestion($request, $question, $i);
            $i ++;
        }
        
        $quizz->setDone(0);
        $quizz->setUser($user->getId());
        $quizz->setDate(new \DateTime());
        $quizz->setStrLevel();
        $quizz->setStrTopic();
        $quizz->setNbQuestion($i);
        
        // Persistance du Quizz
        $em->persist($quizz);
        $em->flush();
        
        foreach($quizz->getQuestions() as $question) {
            $this->questionmanager->setId($question, $quizz);
            $em->persist($question);
        }
        // Persistance du Quizz avec les QuestionId
        $em->persist($quizz);
        $em->flush();
        
    }
    
}