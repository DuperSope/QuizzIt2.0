<?php

namespace QuizzBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class QuizzBundle extends Bundle
{
}
