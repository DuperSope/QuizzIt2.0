<?php

namespace UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use UserBundle\Entity\User;
use UserBundle\Form\UserType;

class SecurityController extends Controller
{

    public function loginAction()
    {
        $authenticationUtils = $this->get('security.authentication_utils');

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render(
            'UserBundle:Security:login.html.twig',
            array(
                // last username entered by the user
                'last_username' => $lastUsername,
                'error'         => $error,
            )
        );
    }
    
    
    public function registerAction()
    {
        $user = new User();
        $form = $this->createForm(UserType::class, $user);
        $request = $this->container->get('request_stack')->getCurrentRequest();
        
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $em = $this->getDoctrine()->getEntityManager();
            $this->addUser($form, $em, $user);
            
            return $this->redirect($this->generateUrl("login"));

        }
        
        return $this->render('UserBundle:Security:register.html.twig',
                array(
                    'form' => $form->createView(),
                ));
    }
    
    public function addUser($form, $em, $user) 
    {
        

        // Chaîne aléatoire pour le salt
        $randomstring = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);
        $user->setSalt($randomstring);  

        // Encodage password
        $factory = $this->get('security.encoder_factory');
        $encoder = $factory->getEncoder($user);
        $password = $encoder->encodePassword($user->getPassword(), $user->getSalt());
        $user->setPassword($password);
        $user->setIsActive(0);

        $user->setRoles(array("ROLE_USER"));
        $user = $form->getData();
        $em->persist($user);
        $em->flush();
        
    }
    

}
